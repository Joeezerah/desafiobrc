﻿using ProjetoBrc.Contexto;
using ProjetoBrc.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjetoBrc.Repositorios
{
    public class ProfessorRepositorio
    {
        private readonly ProjetoBrcContext _contexto;

        public ProfessorRepositorio(ProjetoBrcContext context)
        {
            _contexto = context;
        }
        public List<ProfessorModel> BuscarTodos()
        {
            if (_contexto.Professor.Any())
            {
                return _contexto.Professor.OrderBy(x => x.NomeProfessor).ToList();
            }
            return new List<ProfessorModel>();
        }
        public void Inserir(ProfessorModel professor)
        {
            _contexto.Add(professor);
            _contexto.SaveChanges();
        }

        public ProfessorModel BuscarProfessorPorId(int Id)
        {     
            return  _contexto.Professor.Where(x => x.Id == Id).FirstOrDefault();
        }

    
    }
}
