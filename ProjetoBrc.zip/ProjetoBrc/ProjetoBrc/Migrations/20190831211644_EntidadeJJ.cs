﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ProjetoBrc.Migrations
{
    public partial class EntidadeJJ : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IdadeEntreQuinzeEDezessete",
                table: "Aluno");

            migrationBuilder.DropColumn(
                name: "MaiorDeDezesseis",
                table: "Aluno");

            migrationBuilder.RenameColumn(
                name: "NomeAluno",
                table: "Aluno",
                newName: "nomeAluno");

            migrationBuilder.RenameColumn(
                name: "DataNascimentoAluno",
                table: "Aluno",
                newName: "dataNascimentoAluno");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "nomeAluno",
                table: "Aluno",
                newName: "NomeAluno");

            migrationBuilder.RenameColumn(
                name: "dataNascimentoAluno",
                table: "Aluno",
                newName: "DataNascimentoAluno");

            migrationBuilder.AddColumn<bool>(
                name: "IdadeEntreQuinzeEDezessete",
                table: "Aluno",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "MaiorDeDezesseis",
                table: "Aluno",
                nullable: false,
                defaultValue: false);
        }
    }
}
