﻿using Microsoft.EntityFrameworkCore;
using ProjetoBrc.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjetoBrc.Contexto
{
    public class ProjetoBrcContext : DbContext
    {
        public ProjetoBrcContext(DbContextOptions<ProjetoBrcContext> options)
            : base(options)
        {
        }

        public DbSet<ProfessorModel> Professor { get; set; }
        public DbSet<AlunoModel> Aluno { get; set; }

    }
}
