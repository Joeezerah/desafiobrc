﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ProjetoBrc.Migrations
{
    public partial class EntidadeLast : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "ProfessorMediaDeAlunos",
                table: "Professor",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "IdadeEntreQuinzeEDezessete",
                table: "Aluno",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ProfessorMediaDeAlunos",
                table: "Professor");

            migrationBuilder.DropColumn(
                name: "IdadeEntreQuinzeEDezessete",
                table: "Aluno");
        }
    }
}
