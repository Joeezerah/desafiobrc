﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ProjetoBrc.Models;
using ProjetoBrc.Models.ViewModels;
using ProjetoBrc.Repositorios;

namespace ProjetoBrc.Controllers
{
    public class AlunoController : Controller
    {

        private readonly AlunoRepositorio _alunoRepositorio;
        private readonly ProfessorRepositorio _professorRepositorio;
        public AlunoController(AlunoRepositorio alunoRepositorio, ProfessorRepositorio professorRepositorio)
        {
            _alunoRepositorio = alunoRepositorio;
            _professorRepositorio = professorRepositorio;
        }
        public IActionResult Index()
        {
            var AlunosRegistrados = _alunoRepositorio.ObterMaiorDezesseis().ToList();
            foreach (var item in AlunosRegistrados)
            {
                item.Professor = _professorRepositorio.BuscarProfessorPorId(item.ProfessorModelId);
            }

            return View(AlunosRegistrados);
        }
        public IActionResult Listar()
        {
            var AlunosRegistrados = _alunoRepositorio.BuscarTodos().ToList();
            foreach (var item in AlunosRegistrados)
            {
                item.Professor = _professorRepositorio.BuscarProfessorPorId(item.ProfessorModelId);
            }

            return View(AlunosRegistrados);
        }
        public IActionResult CadastroDeAlunos()
        {
            var professores = _professorRepositorio.BuscarTodos();
            var viewModel = new AlunoModelFormViewModel { ProfessorModels = professores };
            return View(viewModel);

        }

        [HttpPost]
        public IActionResult CadastroDeAlunos(AlunoModelFormViewModel aluno)
        {
            _alunoRepositorio.Inserir(aluno);
            return RedirectToAction(nameof(Index));
        }

    }
}