﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ProjetoBrc.Migrations
{
    public partial class EntidadeFinal : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "MaiorDeDezesseis",
                table: "Aluno",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "MaiorDeDezesseis",
                table: "Aluno");
        }
    }
}
