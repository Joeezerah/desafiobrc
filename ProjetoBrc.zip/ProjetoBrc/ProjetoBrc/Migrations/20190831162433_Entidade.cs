﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ProjetoBrc.Migrations
{
    public partial class Entidade : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_Aluno_ProfessorModelId",
                table: "Aluno",
                column: "ProfessorModelId");

            migrationBuilder.AddForeignKey(
                name: "FK_Aluno_Professor_ProfessorModelId",
                table: "Aluno",
                column: "ProfessorModelId",
                principalTable: "Professor",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Aluno_Professor_ProfessorModelId",
                table: "Aluno");

            migrationBuilder.DropIndex(
                name: "IX_Aluno_ProfessorModelId",
                table: "Aluno");
        }
    }
}
