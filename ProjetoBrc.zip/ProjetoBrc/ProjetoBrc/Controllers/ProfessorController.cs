﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ProjetoBrc.Models;
using ProjetoBrc.Repositorios;

namespace ProjetoBrc.Controllers
{
    public class ProfessorController : Controller
    {

        private readonly ProfessorRepositorio _professorRepositorio;
        private readonly AlunoRepositorio _alunoRepositorio;
        public ProfessorController(ProfessorRepositorio professorService , AlunoRepositorio alunoRepositorio)
        {
            _professorRepositorio = professorService;
            _alunoRepositorio = alunoRepositorio;

        }
        public IActionResult Index()
        {
            var ProfessoresRegistrados = _professorRepositorio.BuscarTodos().ToList();
           
            return View(ProfessoresRegistrados);
        }
        public IActionResult CadastroDeProfessor()
        {
            return View();
        }

        [HttpPost]
        public IActionResult CadastroDeProfessor(ProfessorModel professor)
        {
            _professorRepositorio.Inserir(professor);
            return RedirectToAction(nameof(Index));
        }
        public IActionResult ListagemProfessoresComMedia()
        {

            var AlunosRegistrados = _alunoRepositorio.ObterMediaIdade();
            foreach (var item in AlunosRegistrados)
            { 
                item.Professor = _professorRepositorio.BuscarProfessorPorId(item.ProfessorModelId);
            }

            return View(AlunosRegistrados);
        }

    }
}