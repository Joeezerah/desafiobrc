﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ProjetoBrc.Migrations
{
    public partial class UltimaEntidade : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ProfessorMediaDeAlunos",
                table: "Professor");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "ProfessorMediaDeAlunos",
                table: "Professor",
                nullable: false,
                defaultValue: false);
        }
    }
}
