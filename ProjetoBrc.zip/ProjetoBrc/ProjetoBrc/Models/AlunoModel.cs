﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ProjetoBrc.Models
{
    public class AlunoModel
    {
        public int Id { get; set; }
        [Display(Name = "Alunos")]
        public string nomeAluno { get; set; }
        [Display(Name = "Data de nascimento")]
        [DataType(DataType.Date)]
        public DateTime dataNascimentoAluno { get; set; }
        public ProfessorModel Professor { get; set; }
        public int ProfessorModelId { get; set; }


        public  int IdadeAtual()
        {
            return DateTime.Now.Year - dataNascimentoAluno.Year;
        }


    }
}
