﻿using System.Collections.Generic;

namespace ProjetoBrc.Models.ViewModels
{
    public class AlunoModelFormViewModel
    {
        public AlunoModel AlunoModel { get; set; }
        public ICollection<ProfessorModel> ProfessorModels { get; set; }
    }
}
