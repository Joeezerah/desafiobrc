﻿using MoreLinq;
using ProjetoBrc.Contexto;
using ProjetoBrc.Models;
using ProjetoBrc.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjetoBrc.Repositorios
{
    public class AlunoRepositorio

    {
        const int IDADE_MINIMA = 14;
        const int IDADE_MAXIMA = 18;

        private readonly ProjetoBrcContext _contexto;

        public AlunoRepositorio(ProjetoBrcContext context)
        {
            _contexto = context;
        }
        public List<AlunoModel> BuscarTodos()
        {
            if (_contexto.Aluno.Any())
            {
                return _contexto.Aluno.ToList();
            }
            return new List<AlunoModel>();
        }
        public void Inserir(AlunoModelFormViewModel aluno)
        {
            _contexto.Add(aluno.AlunoModel);
            _contexto.SaveChanges();
        }

        public List<AlunoModel> ObterMaiorDezesseis()
        {
            var AlunosRegistrados = BuscarTodos();
            var ObterMaiorDeDezesseis = ProcurarPorIdade(16, AlunosRegistrados);

            return ObterMaiorDeDezesseis;
        }

        public List<AlunoModel> ObterMediaIdade()
        {
            var AlunosRegistrados = BuscarTodos();
            var ObterMediaIdadePorProfessor = ProcurarMedia(AlunosRegistrados);

            return ObterMediaIdadePorProfessor;
        }

        public List<AlunoModel> ProcurarPorIdade(int idade, List<AlunoModel> list)
        {
            var retorno = list.Where(x => x.IdadeAtual() > idade || x.IdadeAtual() == idade).ToList();

            return retorno;
        }

        public List<AlunoModel> ProcurarMedia(List<AlunoModel> list)
        {

            var listaDeAlunoPorProfessor = list.OrderBy(x => x.ProfessorModelId).GroupBy(x => x.ProfessorModelId);
            double mediaDeIdade = 0;
            var listaDeAlunos = new List<AlunoModel>();

            foreach (var aluno in listaDeAlunoPorProfessor)
            {
                mediaDeIdade = aluno.ToList().Average(x => x.IdadeAtual());
                if (mediaDeIdade > IDADE_MINIMA && mediaDeIdade < IDADE_MAXIMA)
                {
                    
                    listaDeAlunos.AddRange(aluno.DistinctBy(x => x.ProfessorModelId));
                }
            }

            return listaDeAlunos;
        }

    }
}
